// Archival reproduction only. No production files are edited.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
const here=path.dirname(fileURLToPath(import.meta.url));
if(process.argv.length!==3)throw Error('Usage: node reproduce.mjs /absolute/path/to/pinned/experimental-earth');
const source=path.resolve(process.argv[2]);
const manifest=JSON.parse(fs.readFileSync(path.join(here,'source-manifest.json')));
const work=fs.mkdtempSync(path.join(os.tmpdir(),'earth-archived-negative-'));
for(const [name,expected] of Object.entries(manifest)){
 const bytes=fs.readFileSync(path.join(source,name));
 const actual=createHash('sha1').update(`blob ${bytes.length}\0`).update(bytes).digest('hex');
 if(actual!==expected)throw Error(`Pinned source mismatch: ${name}`);
 fs.writeFileSync(path.join(work,name),bytes);
}
fs.writeFileSync(path.join(work,'package.json'),'{"type":"module"}');
for(const name of fs.readdirSync(path.join(here,'frozen'))){
 if(name.endsWith('.mjs')&&name!=='run.mjs')fs.copyFileSync(path.join(here,'frozen',name),path.join(work,name));
}
for(const name of ['build-adaptive-experiment.mjs','adaptive-experiment.mjs'])fs.copyFileSync(path.join(here,name),path.join(work,name));
console.log(`Archived reproduction output: ${work}`);
for(const script of ['paired-cases.test.mjs','dry-source-control.mjs','benchmark-probe.mjs','build-split-probe.mjs','benchmark-split.mjs','build-ssp-probe.mjs','benchmark-ssp.mjs','build-full-ssp-probe.mjs','benchmark-full-ssp.mjs','compare-methods.mjs','compare-ssp.mjs','compare-full-ssp.mjs','equal-work.mjs','verify.mjs','build-adaptive-experiment.mjs','adaptive-experiment.mjs']){
 const result=spawnSync(process.execPath,[path.join(work,script)],{stdio:'inherit',env:process.env});
 if(result.status!==0)process.exit(result.status??1);
}
