import fs from 'node:fs';
const original=fs.readFileSync(new URL('./core.js',import.meta.url),'utf8');
const loop=original.indexOf('  for (let start = 0; start < weather.durationMinutes');
const bodyStart=original.indexOf('    tracer?.rain(rainMm);',loop);
const minute=original.indexOf('    const minute =',bodyStart);
const body=original.slice(bodyStart,minute);
const replacement=`
  if(traceBudget || tracer || origins || wettingFront)throw Error('Adaptive research excludes traced/wetting-front state');
  let suggested=weather.stepMinutes,stages=0,rejected=0,unresolved=0,maxError=0;
  const capture=()=>({water:water.slice(),peak:peak.slice(),rainLiters,absorbedLiters,exitLiters});
  const restore=s=>{water.splice(0,n,...s.water);peak.splice(0,n,...s.peak);rainLiters=s.rainLiters;absorbedLiters=s.absorbedLiters;exitLiters=s.exitLiters;};
  const advance=(start,dtMinutes)=>{
    const dtHours=dtMinutes/60;
    const rainOverlap=Math.max(0,Math.min(start+dtMinutes,weather.stormMinutes)-Math.min(start,weather.stormMinutes));
    const rainMm=weather.rainMmHr*rainOverlap/60;
    ${body}
  };
  for(let start=0;start<weather.durationMinutes-1e-10;){
    let dtMinutes=Math.min(suggested,weather.durationMinutes-start);
    if(start<weather.stormMinutes)dtMinutes=Math.min(dtMinutes,weather.stormMinutes-start);
    const before=capture();let error;
    while(true){
      if(stages+3>100000)throw Error('Adaptive research work bound exhausted');
      advance(start,dtMinutes);const full=capture();restore(before);
      advance(start,dtMinutes/2);advance(start+dtMinutes/2,dtMinutes/2);stages+=3;
      error=Math.max(...water.map((v,i)=>Math.abs(v-full.water[i])),Math.abs(absorbedLiters-full.absorbedLiters)/(n*cellArea),Math.abs(exitLiters-full.exitLiters)/(n*cellArea));
      if(error<=0.02||dtMinutes<=0.0625){if(error>0.02)unresolved++;break;}
      restore(before);dtMinutes=Math.max(0.0625,dtMinutes/2);rejected++;
    }
    maxError=Math.max(maxError,error);
    suggested=Math.min(weather.stepMinutes,error<0.005?dtMinutes*2:dtMinutes);
`;
let generated=original.slice(0,loop)+replacement+original.slice(minute);
generated=generated.replace('    tracer?.endStep(minute);','    start=minute;\n    tracer?.endStep(minute);');
generated=generated.replace('    rainLiters, absorbedLiters, exitLiters, storedLiters, massErrorLiters,','    researchAdaptive:{stages,rejected,unresolved,maxError},\n    rainLiters, absorbedLiters, exitLiters, storedLiters, massErrorLiters,');
fs.writeFileSync(new URL('./adaptive-experiment-core.js',import.meta.url),generated);
