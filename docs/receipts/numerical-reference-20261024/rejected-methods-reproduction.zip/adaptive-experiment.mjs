import fs from 'node:fs';
import {makeExample,runRain as explicit} from './research-core.js';
import {runRain as adaptive} from './adaptive-experiment-core.js';
const cases=JSON.parse(fs.readFileSync(new URL('./full-ssp-comparison.json',import.meta.url)));
const out=[];for(const row of cases){
 const c=row.case,p=makeExample();p.weather.mobilityPerHour=c.mobility;p.weather.rainMmHr=c.rain;
 const changed=structuredClone(p.existing);changed[c.cell].elevationM+=c.shift;
 const a=adaptive(p.existing,p.width,p.height,p.weather),b=adaptive(changed,p.width,p.height,p.weather);
 const count=a.researchAdaptive.stages+b.researchAdaptive.stages;
 const equalStep=2*p.weather.durationMinutes/count;
 const weather={...p.weather,stepMinutes:equalStep};
 const e=explicit(p.existing,p.width,p.height,weather),f=explicit(changed,p.width,p.height,weather);
 out.push({cell:c.cell,shift:c.shift,mobility:c.mobility,rain:c.rain,reference:row.fineReferences[0],adaptive:b.exitLiters+b.storedLiters-a.exitLiters-a.storedLiters,equalWorkExplicit:f.exitLiters+f.storedLiters-e.exitLiters-e.storedLiters,equalStep,stages:count,unresolved:a.researchAdaptive.unresolved+b.researchAdaptive.unresolved,mass:Math.max(Math.abs(a.massErrorLiters),Math.abs(b.massErrorLiters))});
}
fs.writeFileSync(new URL('./adaptive-experiment-results.json',import.meta.url),JSON.stringify(out,null,2));
console.log(JSON.stringify({cases:out.length,adaptiveDisagree:out.filter(r=>Math.sign(r.adaptive)!==Math.sign(r.reference)).length,explicitDisagree:out.filter(r=>Math.sign(r.equalWorkExplicit)!==Math.sign(r.reference)).length,adaptiveMeanAbs:out.reduce((s,r)=>s+Math.abs(r.adaptive-r.reference),0)/out.length,explicitMeanAbs:out.reduce((s,r)=>s+Math.abs(r.equalWorkExplicit-r.reference),0)/out.length,unresolved:out.reduce((s,r)=>s+r.unresolved,0),maxMass:Math.max(...out.map(r=>r.mass))},null,2));
