import {assertPairedCases} from './paired-cases.mjs';
import fs from 'node:fs';
import {makeExample,runRain as explicit} from './research-core.js';
import {runRain as split} from './ssp-core.js';
const old=JSON.parse(fs.readFileSync(new URL('./probe-results.json',import.meta.url))).rows;
const alt=JSON.parse(fs.readFileSync(new URL('./ssp-results.json',import.meta.url))).rows;
assertPairedCases(old,alt);
const sign=x=>Math.abs(x)<1e-7?0:Math.sign(x);
const selected=old.map((r,i)=>({r,s:alt[i]})).filter(({r,s})=>[...r.effects,...s.effects].some(x=>sign(x)!==sign(r.effects[5])));
const output=[];
for(const {r,s} of selected){
 const p=makeExample();p.weather.mobilityPerHour=r.mobility;p.weather.rainMmHr=r.rain;p.weather.stepMinutes=.0625;
 const changed=structuredClone(p.existing);changed[r.cell].elevationM+=r.shift;
 const refs=[];
 for(const run of [explicit,split]){
  const a=run(p.existing,p.width,p.height,p.weather),b=run(changed,p.width,p.height,p.weather);
  refs.push(b.storedLiters+b.exitLiters-a.storedLiters-a.exitLiters);
 }
 output.push({case:r,splitEffects:s.effects,fineReferences:refs});
}
fs.writeFileSync(new URL('./ssp-comparison.json',import.meta.url),JSON.stringify(output));
console.log(JSON.stringify({selected:output.length,fineMethodDisagreements:output.filter(x=>sign(x.fineReferences[0])!==sign(x.fineReferences[1])).length,explicit5Wrong:output.filter(x=>sign(x.case.effects[0])!==sign(x.fineReferences[0])).length,split5Wrong:output.filter(x=>sign(x.splitEffects[0])!==sign(x.fineReferences[0])).length,explicit1Wrong:output.filter(x=>sign(x.case.effects[3])!==sign(x.fineReferences[0])).length,split1Wrong:output.filter(x=>sign(x.splitEffects[3])!==sign(x.fineReferences[0])).length,splitFasterRatio:old.reduce((a,r)=>a+r.milliseconds,0)/alt.reduce((a,r)=>a+r.milliseconds,0)},null,2));
