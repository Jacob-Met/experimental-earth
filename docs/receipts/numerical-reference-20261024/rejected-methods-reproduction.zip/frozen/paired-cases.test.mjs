import assert from 'node:assert/strict';
import {assertPairedCases} from './paired-cases.mjs';
const rows=[{cell:8,shift:.03,mobility:.5,rain:15},{cell:15,shift:-.03,mobility:1,rain:36}];
assertPairedCases(rows,structuredClone(rows));
assert.throws(()=>assertPairedCases(rows,rows.toReversed()),/differ at row/);
assert.throws(()=>assertPairedCases(rows,rows.slice(1)),/counts differ/);
for(const field of ['cell','shift','mobility','rain']){
 const changed=structuredClone(rows);changed[0][field]+=.01;
 assert.throws(()=>assertPairedCases(rows,changed),/differ at row/);
}
console.log('Paired-case identity controls passed.');
