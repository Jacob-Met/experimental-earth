// Research-only refinement experiment; production source is never edited.
import fs from 'node:fs';
import {makeExample,runRain} from './core.js';
const {runRain: refined}=await import('./full-ssp-core.js');
const rows=[];
for(const mobility of (process.env.FLOW_QUICK ? [.5] : [.25,.5,1]))for(const rain of (process.env.FLOW_QUICK ? [0,15] : [0,15,36,120])){
 const p=makeExample();p.weather.mobilityPerHour=mobility;p.weather.rainMmHr=rain;
 const steps=[5,2.5,1.25,1,.5,.25];
 const base=steps.map(step=>refined(p.existing,p.width,p.height,{...p.weather,stepMinutes:step}));
 for(const cell of (process.env.FLOW_QUICK ? [8,15] : Array.from({length:48},(_,i)=>i)))for(const shift of [-.03,.03]){
  const cells=structuredClone(p.existing);cells[cell].elevationM+=shift;
  const effects=[];let mass=0,min=Infinity;const start=performance.now();
  for(let k=0;k<steps.length;k++){
   const r=refined(cells,p.width,p.height,{...p.weather,stepMinutes:steps[k]});
   effects.push(r.storedLiters+r.exitLiters-base[k].storedLiters-base[k].exitLiters);
   mass=Math.max(mass,Math.abs(r.massErrorLiters));min=Math.min(min,...r.finalDepthMm);
  }
  rows.push({mobility,rain,cell,shift,effects,mass,min,milliseconds:performance.now()-start});
 }
}
fs.writeFileSync(new URL('./full-ssp-results.json',import.meta.url),JSON.stringify({steps:[5,2.5,1.25,1,.5,.25],rows}));
const sign=x=>Math.abs(x)<1e-7?0:Math.sign(x);
console.log(JSON.stringify({cases:rows.length,signChanges: [0,1,2,3,4].map(k=>rows.filter(r=>sign(r.effects[k])!==sign(r.effects[k+1])).length),massMax:Math.max(...rows.map(r=>r.mass)),minimumDepth:Math.min(...rows.map(r=>r.min)),example:rows.find(r=>sign(r.effects[2])!==sign(r.effects[3]))},null,2));
