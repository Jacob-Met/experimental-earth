import fs from 'node:fs';
const original=fs.readFileSync(new URL('./core.js',import.meta.url),'utf8');
const begin=original.indexOf('    // Explicit finite-volume pair transfers.');
const end=original.indexOf('    const minute =',begin);
if(begin<0||end<begin)throw Error('Source layout changed');
let flux=original.slice(begin,end).replaceAll('dtHours','hours').replace('      peak[i] = Math.max(peak[i], water[i]);','');
const flow=`
    if(traceBudget || tracer || origins)throw Error('Research SSP excludes tracing');
    const beforeFlow=water.slice(), beforeExit=exitLiters;
    const advanceFlow=(hours)=>{${flux}};
    advanceFlow(dtHours);
    advanceFlow(dtHours);
    for(let i=0;i<n;i++){
      water[i]=(beforeFlow[i]+water[i])/2;
      peak[i]=Math.max(peak[i],water[i]);
    }
    exitLiters=(beforeExit+exitLiters)/2;
`;
fs.writeFileSync(new URL('./ssp-core.js',import.meta.url),(original.slice(0,begin)+flow+original.slice(end)).replace('within(weather.stepMinutes, 1, 30)','within(weather.stepMinutes, 0.01, 30)'));
