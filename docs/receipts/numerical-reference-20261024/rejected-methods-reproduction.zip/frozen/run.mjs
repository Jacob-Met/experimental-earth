import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const here=path.dirname(fileURLToPath(import.meta.url)),root=path.resolve(here,'../..');
const temporary=fs.mkdtempSync(path.join(os.tmpdir(),'earth-flow-research-'));
const queue=['core.js'],manifest={};
while(queue.length){
 const name=queue.pop();if(manifest[name])continue;
 const data=fs.readFileSync(path.join(root,name));
 manifest[name]=createHash('sha1').update(`blob ${data.length}\0`).update(data).digest('hex');
 fs.writeFileSync(path.join(temporary,name),data);
 for(const match of data.toString().matchAll(/from\s+['"]\.\/([^'"]+)['"]/g))queue.push(match[1]);
}
fs.writeFileSync(path.join(temporary,'package.json'),'{"type":"module"}');
fs.writeFileSync(path.join(temporary,'source-manifest.json'),JSON.stringify(manifest,null,2));
for(const name of fs.readdirSync(here))if(name.endsWith('.mjs')&&name!=='run.mjs')fs.copyFileSync(path.join(here,name),path.join(temporary,name));
console.log(`Research output: ${temporary}`);
for(const script of ['paired-cases.test.mjs','dry-source-control.mjs','benchmark-probe.mjs','build-split-probe.mjs','benchmark-split.mjs','build-ssp-probe.mjs','benchmark-ssp.mjs','build-full-ssp-probe.mjs','benchmark-full-ssp.mjs','compare-methods.mjs','compare-ssp.mjs','compare-full-ssp.mjs','equal-work.mjs','verify.mjs']){
 const result=spawnSync(process.execPath,[path.join(temporary,script)],{stdio:'inherit',env:process.env});
 if(result.status!==0)process.exit(result.status??1);
}
