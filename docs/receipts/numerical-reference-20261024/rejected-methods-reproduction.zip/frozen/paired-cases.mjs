import assert from 'node:assert/strict';
export function assertPairedCases(left,right){
 assert.equal(left.length,right.length,'Research case counts differ');
 for(let i=0;i<left.length;i++){
  const key=row=>[row.cell,row.shift,row.mobility,row.rain];
  assert.deepEqual(key(left[i]),key(right[i]),`Research cases differ at row ${i}`);
 }
}
