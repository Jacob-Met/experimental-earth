import fs from 'node:fs';
const original=fs.readFileSync(new URL('./core.js',import.meta.url),'utf8');
const begin=original.indexOf('    // Explicit finite-volume pair transfers.');
const end=original.indexOf('    const minute =',begin);
if(begin<0||end<begin)throw Error('Source layout changed');
// Exact two-reservoir linear head relaxation; palindromic splitting limits
// ordering bias while retaining each subflow's conservation and positivity.
const flow=`
    if (traceBudget || tracer || origins || cells.some(c => c.internalBarriers)) throw Error('Research splitting excludes tracing/barriers');
    const operations = [...pairs.map(([a,b])=>({a,b})),...boundaries.map(([a,count])=>({a,count}))];
    const apply = (op,hours) => {
      const {a,b,count}=op;
      if (b === undefined) {
        const left=Math.max(0,(water[a]+10)*Math.exp(-weather.boundaryExitPerHour*count*hours)-10);
        exitLiters+=(water[a]-left)*cellArea;water[a]=left;return;
      }
      if(internalEdgeClosed(cells,a,b,width)||internalEdgeCrest(cells,a,b)!==null) throw Error('Research splitting excludes barriers');
      const delta=(cells[a].elevationM-cells[b].elevationM)*1000+water[a]-water[b];
      const requested=delta*(-Math.expm1(-2*weather.mobilityPerHour*hours))/2;
      const moved=Math.max(-water[b],Math.min(water[a],requested));
      water[a]-=moved;water[b]+=moved;
    };
    for(const op of operations)apply(op,dtHours/2);
    for(let k=operations.length-1;k>=0;k--)apply(operations[k],dtHours/2);
    for(let i=0;i<n;i++)peak[i]=Math.max(peak[i],water[i]);
`;
fs.writeFileSync(new URL('./split-core.js',import.meta.url),(original.slice(0,begin)+flow+original.slice(end)).replace('within(weather.stepMinutes, 1, 30)','within(weather.stepMinutes, 0.01, 30)'));
