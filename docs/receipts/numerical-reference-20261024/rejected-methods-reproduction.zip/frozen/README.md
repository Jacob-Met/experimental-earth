# Research: conservative flow composition

Status: reproducible numerical research; do not adopt these candidates into runRain.

The existing exact core blob is dfba77314eae03626b626002113485230a2bccb0.
All18dependency files match maintained tree9982d98d26a4fa727d57047df2bc9c15647d15ae.
Each execution retains the exact Git blob manifest of the source it actually runs.

## Reproduce

From repository root, run `node research/flow-integration/run.mjs`. A fresh
OS temporary directory receives the source dependency closure, generated research
variants, exact blob manifest and JSON results. Production files remain untouched.
The output directory is printed first and retained for inspection. For a short
changed-input/dry/false-stability course, use
`FLOW_QUICK=1 node research/flow-integration/run.mjs` (8 cases).
No packages, network, credentials, physical operations or external data required.
The individual commands below describe scripts inside that temporary directory.


Run `node benchmark-probe.mjs`, `node build-split-probe.mjs`,
`node benchmark-split.mjs`, then `node compare-methods.mjs`.
Generated research-core.js changes only minimum step admission. split-core.js
also replaces simultaneous proportional source-capped fluxes with exact pair
relaxations composed in a forward/reverse half-step sweep. The boundary sink is
integrated exponentially with a zero-depth stop. No project settings are adopted.
The candidate deliberately refuses tracing and internal barriers.

## Selection and controls

The authored courtyard has 48 cells. Each receives either -0.03 or +0.03m grade
change, for three mobility coefficients (.25/.5/1 per hour), four rain rates
(0/15/36/120 mm/h), and six intervals (5/2.5/1.25/1/.5/.25min). This gives1152
cases. All pairs use exactly matched baseline and proposal weather.
Dry rain controls and both grade-change signs are retained. These are model
experiments, not field observations or evidence of physical accuracy.

## Findings

Adjacent-interval direction changes for explicit flow:11,5,4,2,1.
For exact pair splitting:12,7,3,1,0. Maximum water balance errors are respectively
2.706e-9 and2.724e-9L; both have minimum final depth0. Runtime is approximately
equal in this single-process exploratory sweep, not a formal performance claim.

Two explicit cases have the same effect direction at5/2.5/1.25min but reverse
at.25min. Repeated direction agreement cannot certify convergence.

The53cases displaying any direction disagreement were also computed with both
methods at.0625min. The methods still disagree in32cases. Relative to the fine
explicit calculation, explicit5min disagrees11times and split5min36times;
explicit1min disagrees3times and split1min32times. The fine explicit run is a
numerical comparison reference, not ground truth.

A concrete loss: mobility.25/h, rain15mm/h, cell1 raised.03m changes water not
absorbed by approximately-.398908L in fine explicit flow versus+5.124621L in
fine split flow. Conservation alone therefore fails to establish equivalence.
Sequential dry-source competition and immediate redistribution are plausible
causes, requiring isolated mechanistic controls before attributing causality.

## Integration decision

Reject production adoption of this pair-split candidate. It preserves totals
but substantially changes downstream intervention decisions, including at the
smallest reference interval. Keep existing production semantics and retain this
counterexample when investigating alternatives. Do not describe fewer fine-step
sign changes as improved physical accuracy or numerical equivalence.


## Dry-source isolation

`node dry-source-control.mjs` exercises one source supplied dt volume with two
downhill demands2dt anddt. Simultaneous allocation gives fractions2/3 and1/3.
The exact palindromic pair composition approaches1 and0 as dt tends to zero;
reversing edge order approaches1/2 and1/2. Every course conserves supply.
This establishes a concrete allocation/order difference in the almost-dry
regime. It does not prove that every full-grid disagreement has this cause.

## Second candidate: simultaneous SSP composition

`node build-ssp-probe.mjs` generates a research-only strong-stability-preserving
two-stage flow composition. It applies the original simultaneous conservative
flow twice, then averages initial/final water and cumulative discharge. Each
stage remains positive and conservative. Rain/infiltration still use the original
operator splitting, so this is not a claim of second-order whole-model accuracy.
Tracing is refused because stage-averaged provenance has not been implemented.
Run `node benchmark-ssp.mjs` and `node compare-ssp.mjs`.

Across the same1152cases its adjacent-step classification changes are10/6/3/2/2,
with max mass error2.704e-9L and minimum depth0. The cell15 dry-source control
oscillates in direction through1minute; this is not decisive reliability gain.

Flow-only SSP at.0625min disagrees in20of40selected cases with maintained fine
flow. Against that reference, five-minute counts are21(SSP) vs11(explicit),
and one-minute counts16vs3. Its runtime is approximately21%greater. Reject
this composition too: applying rain once before two flow stages may change
allocation in the dry forced regime.

A third research candidate includes rainfall and infiltration in both original
Euler stages, averaging all four water/rain/infiltration/outflow inventories.
`build-full-ssp-probe.mjs`, `benchmark-full-ssp.mjs`, `compare-full-ssp.mjs`
reproduce it. The candidate refuses wetting-front state and tracing. Peak
statistics are unqualified because internal stages are not physical timestamps;
only final stored+outflow outcomes are evaluated. Adjacent direction changes
are14/4/1/1/0, mass error2.717e-9L, minimum final depth0. Adoption remains
unqualified pending finer reference comparison and complete consumer semantics.


## Matched-stage-work consumer comparison

Within the22cases selected for direction disagreement between maintained and
full-step SSP courses, two explicit half-size steps are compared against one
two-stage SSP step. This matches Euler-stage evaluations, not wall-clock runtime.
At SSP5/explicit2.5min, reference-sign disagreements are13vs4; at2.5/1.25min,
3vs3; at1/.5min,2vs1. Mean absolute differences from the explicit.0625min
reference are respectively.682vs.446L,.285vs.290L,.155vs.101L.
The complete selected-case gain/loss ledger is generated by equal-work.mjs.
This is a deliberately selected stress set, not population failure probability.
The fine explicit calculation is not certified converged truth; retained cell8
actually reverses again between.25and.0625min.

There is no demonstrated equal-work consumer advantage sufficient to adopt the
SSP candidate or to justify building an adaptive product path on it. Preserve
production behavior. A future method must explicitly preserve the dry-source
competition semantics, compare equal work, and qualify event-boundary forcing,
peak history, tracer/provenance and wetting-front state before adoption.


## Current-source receiving

The complete1152-case course for all four methods was rerun with all18 dependency
blobs matching maintained tree9982d98d26a4fa727d57047df2bc9c15647d15ae.
The independent verification script passed finite results, mass error below1e-6L,
nonnegative final depths,288zero-rain cases per method, and the retained cell15
false-stability witness. The final8-case quick course also passed.

Comparison inputs must match cell, grade shift, mobility and rain in every row,
and must have equal length. Focused mismatch controls prove reordered rows,
missing cases and changes to each identity field are refused before pairing.
