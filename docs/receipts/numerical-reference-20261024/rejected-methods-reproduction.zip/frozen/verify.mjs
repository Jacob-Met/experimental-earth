import fs from 'node:fs';
import assert from 'node:assert/strict';
for(const name of ['probe','split','ssp','full-ssp']){
 const {rows}=JSON.parse(fs.readFileSync(new URL(`./${name}-results.json`,import.meta.url)));
 assert.equal(rows.length,process.env.FLOW_QUICK?8:1152);
 for(const row of rows){
  assert.ok(row.effects.every(Number.isFinite));
  assert.ok(Number.isFinite(row.mass)&&row.mass<1e-6);
  assert.ok(row.min>=0);
  if(row.rain===0)assert.ok(row.effects.every(x=>x===0));
 }
}
const explicit=JSON.parse(fs.readFileSync(new URL('./probe-results.json',import.meta.url))).rows;
const witness=explicit.find(r=>r.cell===15&&r.shift===.03&&r.mobility===.5&&r.rain===15);
assert.ok(witness.effects.slice(0,5).every(x=>x<0));
assert.ok(witness.effects[5]>0);
console.log('Qualified conservation, positivity, dry controls and retained false-stability witness.');
