import fs from 'node:fs';
const rows=JSON.parse(fs.readFileSync(new URL('./full-ssp-comparison.json',import.meta.url)));
const sign=x=>Math.abs(x)<1e-7?0:Math.sign(x);
const out=[];
for(const [fullStep,fullIndex,explicitStep,explicitIndex] of [[5,0,2.5,1],[2.5,1,1.25,2],[1,3,.5,4]]){
 let explicitWrong=0,fullWrong=0,explicitAbs=0,fullAbs=0;
 const losses=[],gains=[];
 for(const row of rows){
  const ref=row.fineReferences[0],e=row.case.effects[explicitIndex],s=row.splitEffects[fullIndex];
  const ew=sign(e)!==sign(ref),sw=sign(s)!==sign(ref);
  explicitWrong+=ew;fullWrong+=sw;explicitAbs+=Math.abs(e-ref);fullAbs+=Math.abs(s-ref);
  const detail={cell:row.case.cell,shift:row.case.shift,mobility:row.case.mobility,rain:row.case.rain,reference:ref,explicit:e,fullSSP:s};
  if(sw&&!ew)losses.push(detail);if(ew&&!sw)gains.push(detail);
 }
 out.push({fullStep,explicitStep,selectedCases:rows.length,explicitWrong,fullWrong,meanAbsoluteDifferenceLiters:{explicit:explicitAbs/rows.length,fullSSP:fullAbs/rows.length},losses,gains});
}
fs.writeFileSync(new URL('./equal-work-results.json',import.meta.url),JSON.stringify(out,null,2));console.log(JSON.stringify(out,null,2));
