import assert from 'node:assert/strict';
// One freshly supplied, almost dry source has two downhill destinations.
// Supply and requested flows shrink together with interval: clipping never
// enters the smooth, well-wetted regime assumed by splitting error arguments.
function simultaneous(dt){
 const water=dt,requests=[2*dt,dt],scale=Math.min(1,water/(3*dt));
 return requests.map(x=>x*scale);
}
function split(dt,reverse=false){
 let water=dt;const received=[0,0];
 const edges=reverse?[1,0]:[0,1];
 for(const i of [...edges,...edges.toReversed()]){
  const gradient=[2,1][i]+water;
  const moved=Math.min(water,gradient*(-Math.expm1(-dt))/2);
  received[i]+=moved;water-=moved;
 }
 return {received,remaining:water};
}
const rows=[];
for(const dt of [1e-2,1e-4,1e-6]){
 const a=simultaneous(dt),b=split(dt),c=split(dt,true);
 for(const x of [b,c])assert.ok(Math.abs(x.received.reduce((a,b)=>a+b,0)+x.remaining-dt)<1e-14);
 assert.ok(Math.abs(a[0]/dt-2/3)<1e-12);
 rows.push({dt,simultaneousFractions:a.map(x=>x/dt),forwardFractions:b.received.map(x=>x/dt),reverseFractions:c.received.map(x=>x/dt)});
}
console.log(JSON.stringify(rows,null,2));
