import fs from 'node:fs';
const original=fs.readFileSync(new URL('./core.js',import.meta.url),'utf8');
const begin=original.indexOf('    tracer?.rain(rainMm);');
const end=original.indexOf('    const minute =',begin);
if(begin<0||end<begin)throw Error('Source layout changed');
const stage=original.slice(begin,end);
const body=`
    if(traceBudget || tracer || origins || wettingFront)throw Error('Research full SSP excludes tracing/wetting front');
    const beforeWater=water.slice(),beforeRain=rainLiters,beforeAbsorb=absorbedLiters,beforeExit=exitLiters;
    const advanceStage=()=>{${stage}};
    advanceStage();advanceStage();
    for(let i=0;i<n;i++)water[i]=(beforeWater[i]+water[i])/2;
    rainLiters=(beforeRain+rainLiters)/2;
    absorbedLiters=(beforeAbsorb+absorbedLiters)/2;
    exitLiters=(beforeExit+exitLiters)/2;
`;
fs.writeFileSync(new URL('./full-ssp-core.js',import.meta.url),(original.slice(0,begin)+body+original.slice(end)).replace('within(weather.stepMinutes, 1, 30)','within(weather.stepMinutes, 0.01, 30)'));
