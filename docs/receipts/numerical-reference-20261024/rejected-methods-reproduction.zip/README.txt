ARCHIVAL NEGATIVE-RESULT REPRODUCTION — NOT A MAINTAINED BENCHMARK

Source: Experimental Earth tree 9982d98d26a4fa727d57047df2bc9c15647d15ae.
The 18 exact source Git blob hashes in source-manifest.json are authoritative.
No production-source copy or credentials are included. No network is required.

Extract this ZIP outside the repository. With Node >=20 and a checkout providing
those exact source blobs, run:
  node reproduce.mjs /absolute/path/to/experimental-earth
The wrapper refuses source mismatch, stages the source closure and experiments in
an OS temporary directory, and prints its path. It leaves all generated sweeps
there for inspection. No source checkout files are modified. The full course runs
1152 cases per method followed by selected fine-reference and equal-work cases.
A short mechanism/receiving course is available with FLOW_QUICK=1, but its smaller
case counts DO NOT reproduce the full reported statistics.

The frozen/ files are the preserved, rejected research scripts and their original
notes, not an additional supported product API. Their old run.mjs is superseded
for this archive by reproduce.mjs. Frozen README paths describe the original
working experiment. Use the maintained evaluation/numerical-methods.mjs for
current numerical-method evaluation and --wet-columns for analytic receiving.

The archived dry-source-control is an earlier simplified allocation illustration
with prescribed receiver heads; it is not the stronger fully source/destination
head control in the maintained evaluation/dry-source-counterexample.js. Sweep
comparisons use their generated full-grid candidate kernels, independently of
that local illustrative script. No candidate kernel is adopted into production.

Receipts:
- source-manifest.json: exact maintained input dependencies.
- frozen/representative-results.json: three retained raw loss/control cases.
- equal-work-results.json: complete selected-case gain/loss ledger for full SSP.
- adaptive-experiment-results.json: 22 adaptive/fixed equal-stage comparisons.
- source-receipt.json: interpretation, commands and observed result summary.

Arithmetic outputs should reproduce within floating-point tolerance. Runtime
measurements vary by machine and load and are not expected to match bytewise.
The .0625-minute incumbent is a numerical reference, NOT certified convergence
or physical truth. Stress-case selection is explicit in compare scripts and is
not a population failure probability. Rejected candidates deliberately do not
qualify tracer, wetting-front or intermediate-stage peak behavior.
